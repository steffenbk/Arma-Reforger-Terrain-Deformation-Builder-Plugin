Terrain deformation - map maker tools

The MUD Ground build plugin (Workbench, Plugins menu) runs these python scripts to cut the terrain.
They can't run from inside the Workshop download, so they come as this separate zip.
The mod (needed as a dependency): https://reforger.armaplatform.com/workshop/6A940DE9528954EE-Terraindeformation

1. Install Python 3 (python.org, tick 'Add python to PATH'), then restart Workbench.
2. Unzip so the scripts sit in a folder named Tools at the top of YOUR mod project:
   <your project>/Tools/mud_build.py  (next to your addon.gproj)
3. In Workbench run MUD Ground: Status - it checks python and the Tools folder.

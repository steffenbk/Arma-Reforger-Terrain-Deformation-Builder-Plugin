Terrain deformation - map maker tools

The MUD Ground build plugin (Workbench, Plugins menu) runs these python scripts to cut the terrain.
They can't run from inside the Workshop download, so they come as this separate zip.
The mod (needed as a dependency): https://reforger.armaplatform.com/workshop/6A940DE9528954EE-Terraindeformation

Normally you don't need this zip: the plugin downloads it for you.
1. Install Python 3 (python.org, tick 'Add python to PATH').
2. Add the Terrain deformation mod to your project's dependencies, then restart Workbench.
3. In the World Editor run Plugins > MUD Ground > 1: Install / update tools.

By hand (no internet in Workbench): unzip so the scripts sit in a folder named Tools at the top of YOUR project:
   <your project>/Tools/mud_build.py  (next to your addon.gproj)
Then run Plugins > MUD Ground > 2: Check world - it checks python and the Tools folder.
